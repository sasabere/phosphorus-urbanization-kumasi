# Guide: Converting Your Original Script to Modules

This document explains how to split your original R script (`R_P_analysis_2026_JBR.R`) into the four module files.

---

## Module Structure

Your original script has approximately 1810 lines. Split it as follows:

### **Module 1: Data Preparation** (`01_data_preparation.R`)
**Lines:** ~1-699 (before the `write.csv()` call)

**Content:**
- Load base datasets (lines 54-101)
- Load total P data (HNO₃ and multi-acid) (lines 110-132)
- Regression to fill missing P values (lines 134-183)
- Load P fractionation data (lines 214-270)
- Calculate P stocks and percentages (lines 272-375)
- Join all datasets (lines 377-420)
- Filter and prepare final dataset (lines 422-699)

**Key output:** `ksitotal_P` dataframe

**Template:**
```r
################################################################################
# Module 1: Data Preparation
# Loads, merges, and prepares soil P data for analysis
################################################################################

cat("Loading base datasets...\n")

# Load base data
ksi_basedata <- read.csv("data/ksitotal_P.csv")  # Or construct from raw files

# [Your data loading and merging code here]

cat("✓ Data preparation complete\n")
cat("  Samples:", nrow(ksitotal_P), "\n")
cat("  Variables:", ncol(ksitotal_P), "\n\n")
```

---

### **Module 2: Descriptive Statistics** (`02_descriptive_stats.R`)
**Lines:** ~700-1200 (statistical analyses)

**Content:**
- Descriptive statistics by urbanization class
- Linear models testing urbanization effects
- Šidák-adjusted pairwise contrasts
- Summary statistics tables

**Key analyses:**
- Effects of urbanization on P stocks
- Comparisons among weak/mild/moderate/strong classes
- Linear contrasts along gradient

**Template:**
```r
################################################################################
# Module 2: Descriptive Statistics and Linear Models
# Tests effects of urbanization on P stocks and fractions
################################################################################

cat("Running statistical analyses...\n")

# Load prepared data (if not in workspace)
if (!exists("ksitotal_P")) {
  source("scripts/modules/01_data_preparation.R")
}

# [Your statistical analysis code here]
# - Linear models
# - Contrasts
# - Summary tables

cat("✓ Statistical analyses complete\n\n")
```

---

### **Module 3: Visualizations** (`03_visualizations.R`)
**Lines:** ~1200-1645 (all plotting code)

**Content:**
- Figure 1: HNO₃ vs. multi-acid comparison
- Figure 2-3: Boxplots of P stocks  
- Figure 4: Stacked bar charts
- Figure 5: Relative contributions
- Figure 6: PPa relationships with reserve pools

**Export locations:**
- PDF: `output/figures/*.pdf`
- PNG: `output/figures/*.png`

**Template:**
```r
################################################################################
# Module 3: Visualizations
# Generates all manuscript figures
################################################################################

cat("Generating figures...\n")

# Create output directory
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)

# Load data if needed
if (!exists("ksitotal_P")) {
  source("scripts/modules/01_data_preparation.R")
}

# [Your plotting code here]
# Save each figure to output/figures/

cat("✓ All figures saved to output/figures/\n\n")
```

---

### **Module 4: SEM Analysis** (`04_SEM_analysis.R`)
**Lines:** ~1647-1810 (SEM models)

**Content:**
- Data preparation for SEM (log transformations)
- Model specification
- Multi-group SEM (by urbanization class and road class)
- Path diagrams
- Model summaries

**Template:**
```r
################################################################################
# Module 4: Structural Equation Modeling
# Multi-group SEM testing pathways from soil properties → P reserves → PPa
################################################################################

cat("Running SEM analysis...\n")

# Load required packages
library(lavaan)
library(semPlot)

# Load data if needed
if (!exists("ksitotal_P_filtered_urban_data")) {
  source("scripts/modules/01_data_preparation.R")
  # [Add filtering steps if needed]
}

# [Your SEM code here]
# - Model specification
# - Model fitting
# - Path diagrams

cat("✓ SEM analysis complete\n\n")
```

---

## Step-by-Step Conversion Process

### 1. **Backup Your Original Script**
```bash
cp R_P_analysis_2026_JBR.R R_P_analysis_2026_JBR_ORIGINAL.R
```

### 2. **Extract Each Module**

For each module:

a. Open your original script  
b. Copy the relevant line ranges (see above)  
c. Paste into new module file  
d. Add module header (see templates)  
e. Remove duplicate package loading (centralized in `load_packages.R`)  
f. Update file paths (use relative paths from project root)  
g. Add progress messages (`cat()` statements)

### 3. **Update File Paths**

**Original (absolute paths):**
```r
setwd("C:/Users/sasaber/ownCloud...")
data <- read.csv("C:/Users/sasaber/...")
```

**Module (relative paths):**
```r
# No setwd() needed - run from project root
data <- read.csv("data/ksitotal_P.csv")
```

### 4. **Remove Redundant Code**

**Remove from modules:**
- `rm(list=ls())` - Only in master script
- `setwd()` - Use relative paths
- Package loading - Centralized in `load_packages.R`
- Duplicate source files - Load once in master script

### 5. **Test Each Module**

```r
# Test individually
source("scripts/modules/01_data_preparation.R")
source("scripts/modules/02_descriptive_stats.R")
source("scripts/modules/03_visualizations.R")
source("scripts/modules/04_SEM_analysis.R")

# Test complete pipeline
source("scripts/run_full_analysis.R")
```

---

## Common Issues and Solutions

### **Issue:** "Object not found" errors
**Solution:** Ensure previous modules are run first or load workspace

### **Issue:** File path errors
**Solution:** Use `file.path()` for cross-platform compatibility:
```r
data_path <- file.path("data", "ksitotal_P.csv")
```

### **Issue:** Package conflicts
**Solution:** Use explicit namespace:
```r
dplyr::select()  # instead of select()
plyr::join()     # instead of join()
```

---

## Workspace Management

### **Option A: Pass data between modules**
Each module loads/saves workspace:
```r
# End of Module 1
save(ksitotal_P, file = "output/prepared_data.RData")

# Start of Module 2
load("output/prepared_data.RData")
```

### **Option B: Keep in memory (recommended)**
Run all modules in sequence via master script - data stays in workspace

---

## Verification Checklist

- [ ] All modules run without errors
- [ ] Figures match original script output
- [ ] Statistical results identical to original
- [ ] No absolute file paths remain
- [ ] All output goes to `output/` folder
- [ ] Master script runs complete pipeline
- [ ] README documents the workflow

---

## Questions?

Contact: stephen.asabere@uni-goettingen.de

---

*This guide helps maintain reproducibility while improving code organization*
