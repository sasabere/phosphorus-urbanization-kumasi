# Urbanization and Soil Phosphorus in Tropical West Africa

[![DOI](https://img.shields.io/badge/DOI-10.25625%2FDA3TOR-blue)](https://doi.org/10.25625/DA3TOR)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![R](https://img.shields.io/badge/R-%3E%3D4.0.0-blue)](https://www.r-project.org/)

## Overview

R code and analysis pipeline for:

**"Oxide-occluded to calcium-bound: Urbanization increases soil phosphorus stocks and diversifies pools in tropical West African agroecosystems"**

*Journal of Geophysical Research: Biogeosciences* (2025) [DOI pending]

---

## Key Findings

- **Urbanization more than doubles soil P stocks** in tropical urban croplands
- **Calcium-bound P emerges as major pool** (unusual in strongly weathered tropical soils)  
- **Dual-pathway P control** develops: oxide + calcium pathways operate simultaneously
- **Plant-available P increases** substantially with urban influence
- **Inadvertent P accumulation** from urban waste creates opportunities for sustainable P management

---

## Quick Start

```r
# 1. Install packages
source("scripts/utils/load_packages.R")

# 2. Download data from Dataverse
source("data/download_data.R")

# 3. Run complete analysis
source("scripts/run_full_analysis.R")
```

---

## Repository Structure

```
phosphorus-urbanization-kumasi/
├── README.md                      # This file
├── LICENSE                        # CC BY 4.0 license
├── CITATION.cff                   # Citation metadata
├── .gitignore                     # Git ignore rules
│
├── scripts/
│   ├── run_full_analysis.R        # Master script (runs entire pipeline)
│   │
│   ├── modules/
│   │   ├── 01_data_preparation.R  # Data loading & processing
│   │   ├── 02_descriptive_stats.R # Statistical analyses
│   │   ├── 03_visualizations.R    # Figure generation
│   │   └── 04_SEM_analysis.R      # Structural equation modeling
│   │
│   └── utils/
│       └── load_packages.R        # Package management
│
├── data/
│   ├── README.md                  # Data access instructions
│   └── download_data.R            # Download from Dataverse
│
├── output/
│   ├── figures/                   # Generated plots (not tracked)
│   └── tables/                    # Statistical outputs (not tracked)
│
└── docs/
    └── packages.txt               # Package dependencies
```

---

## Dataset

**Location:** University of Göttingen Research Data Repository  
**DOI:** https://doi.org/10.25625/DA3TOR  
**File:** ksitotal_P.csv (225 samples × 81 variables)

**Contents:**
- Soil P fractionation data (PPa, PSOM, PCa, POCC)
- Total P stocks (HNO₃ and multi-acid extraction)
- Soil properties (pH, SOC, exchangeable Ca, ECEC)
- Urbanization classification (weak → strong gradient)
- Quality flags (LOQ status for each fraction)

---

## Installation

### System Requirements

- **R:** ≥ 4.0.0 (tested on R 4.3.0)
- **OS:** Windows, macOS, or Linux  
- **RAM:** ≥ 4 GB recommended

### Setup

1. **Clone repository:**
   ```bash
   git clone https://github.com/sasabere/phosphorus-urbanization-kumasi.git
   cd phosphorus-urbanization-kumasi
   ```

2. **Install R packages:**
   ```r
   source("scripts/utils/load_packages.R")
   ```

3. **Download dataset:**
   ```r
   source("data/download_data.R")
   # OR download manually from https://doi.org/10.25625/DA3TOR
   ```

---

## Usage

### Run Full Pipeline

```r
source("scripts/run_full_analysis.R")
```

Executes:
1. Data preparation & stock calculations
2. Descriptive statistics & linear models  
3. Figure generation (all manuscript plots)
4. SEM analysis

### Run Individual Modules

```r
# Data prep only
source("scripts/modules/01_data_preparation.R")

# Stats only
source("scripts/modules/02_descriptive_stats.R")

# Figures only  
source("scripts/modules/03_visualizations.R")

# SEM only
source("scripts/modules/04_SEM_analysis.R")
```

---

## Methods Summary

### P Fractionation

Sequential extraction separating four operational pools:

| Fraction | Extraction | Interpretation |
|----------|------------|----------------|
| **PPa** | 0.5 M NaHCO₃ (pH 8.5) | Plant-available P |
| **PSOM** | H₂O₂–acetate | Organic matter-bound P |
| **PCa** | Mild HCl–acetate | Calcium-bound P |
| **POCC** | Dithionite–citrate–bicarbonate | Oxide-occluded P |
| **Total P** | HNO₃ digestion | All soil P |

### Statistical Analysis

- **Linear models:** Urbanization effects on P stocks
- **Contrasts:** Šidák-adjusted pairwise comparisons  
- **Correlations:** PPa vs. reserve pools (PSOM, PCa, POCC)
- **SEM:** Multi-group structural equation models

---

## Figures

The code reproduces all manuscript figures:

- **Fig. 1:** HNO₃ vs. multi-acid total P comparison
- **Fig. 2-3:** P stocks across urbanization gradient  
- **Fig. 4:** Fraction stocks by urbanization class
- **Fig. 5:** Relative P fraction contributions
- **Fig. 6:** PPa relationships with reserve pools
- **Fig. 7:** SEM path diagrams

Output: `output/figures/` (PDF + PNG formats)

---

## Citation

### Paper

```
Asabere, S.B., [Co-authors]. (2025). Oxide-occluded to calcium-bound: 
Urbanization increases soil phosphorus stocks and diversifies pools in 
tropical West African agroecosystems. Journal of Geophysical Research: 
Biogeosciences. https://doi.org/[pending]
```

### Data

```
Asabere, S.B., [Co-authors]. (2025). Soil Phosphorus Stocks and 
Partitioning Along an Urbanization Gradient in Kumasi, Ghana [Dataset]. 
University of Göttingen. https://doi.org/10.25625/DA3TOR
```

### Code

```
Asabere, S.B. (2025). R code for: Urbanization and soil phosphorus in 
tropical West Africa (v1.0). GitHub. 
https://github.com/sasabere/phosphorus-urbanization-kumasi
```

Or use `CITATION.cff` for automatic citation.

---

## License

**Code:** CC BY 4.0 (Creative Commons Attribution 4.0 International)  
**Data:** CC BY 4.0 (see Dataverse)

You are free to share and adapt with attribution. See [LICENSE](LICENSE).

---

## Funding

Deutsche Forschungsgemeinschaft (DFG), project **467340364**

---

## Acknowledgments

- **Lab support:** Jago Birk, Petra Voigt, Anja Soedje (Univ. Göttingen)
- **P fractionation:** Dr. Harold J. Hughes  
- **Research assistance:** Jianghu Li, Tino Poeplau
- **Field access:** Farmers in Kumasi, Ghana

---

## Contact

**Stephen Baffoe Asabere**  
Department of Physical Geography  
University of Göttingen  
📧 stephen.asabere@uni-goettingen.de  
🔗 [GitHub](https://github.com/sasabere)

---

## Version History

- **v1.0.0** (Feb 2025): Initial release with manuscript publication

---

*Repository maintained by Stephen Asabere | Last updated: February 2025*
